#!/bin/bash
THRESHOLD_SHOW=5
THRESHOLD_HIDE=50
POLL=0.2
# 3s delay = 3 / 0.2 = 15 ticks
DELAY_TICKS=15
BAR_VISIBLE=true
TICK=0

while true; do
    Y=$(hyprctl cursorpos 2>/dev/null | grep -oP '^\d+, \K\d+')
    Y=${Y:-999}

    if [ "$Y" -lt "$THRESHOLD_SHOW" ]; then
        # Chuột lên → reset tick, hiện bar
        TICK=0
        if [ "$BAR_VISIBLE" = false ]; then
            hyprctl keyword layerrule "blur, waybar" &>/dev/null
            killall -SIGUSR2 waybar 2>/dev/null
            BAR_VISIBLE=true
        fi

    elif [ "$Y" -gt "$THRESHOLD_HIDE" ] && [ "$BAR_VISIBLE" = true ]; then
        # Chuột xuống → đếm tick
        TICK=$((TICK + 1))
        if [ "$TICK" -ge "$DELAY_TICKS" ]; then
            hyprctl keyword layerrule "noblur, waybar" &>/dev/null
            sleep 0.05
            killall -SIGUSR1 waybar 2>/dev/null
            BAR_VISIBLE=false
            TICK=0
        fi

    else
        # Chuột trong vùng 5-50px → reset tick, giữ nguyên
        TICK=0
    fi

    sleep "$POLL"
done
