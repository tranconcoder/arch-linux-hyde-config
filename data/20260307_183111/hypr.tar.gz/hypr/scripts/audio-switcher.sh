#!/bin/bash

# Lấy danh sách sink (output device)
sinks=$(pactl list sinks | grep -E "Name:|Description:" | paste - - | \
  awk -F'\t' '{
    gsub(/.*Name: /, "", $1); 
    gsub(/.*Description: /, "", $2); 
    print $2 "|" $1
  }')

# Lấy sink đang active
current=$(pactl get-default-sink)

# Hiển thị menu Rofi
chosen=$(echo "$sinks" | awk -F'|' '{print $1}' | \
  rofi -dmenu -i -p "🔊 Audio Output" -theme-str 'window {width: 40%;}')

# Set sink được chọn
if [ -n "$chosen" ]; then
  sink_name=$(echo "$sinks" | grep "^$chosen|" | awk -F'|' '{print $2}')
  pactl set-default-sink "$sink_name"
  
  # Chuyển tất cả app đang chạy sang sink mới
  pactl list sink-inputs | grep "Sink Input" | awk '{print $3}' | \
    while read input; do
      pactl move-sink-input "$input" "$sink_name"
    done
  
  notify-send "🔊 Audio Output" "Đã chuyển sang: $chosen"
fi
