#!/usr/bin/env python3
import time
import os
import sys

ACPI_CALL = "/proc/acpi/call"
# TARGET_OFFSET_ORIGIN = 0x40B 
TARGET_OFFSET = 0x40B 

def write_ec_byte(offset, value):
    cmd = f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset)} {hex(value)}"
    with open(ACPI_CALL, "w") as f: f.write(cmd)
    
def main():
    if os.geteuid() != 0:
        print("Run as root")
        sys.exit(1)

    print("Attempting to FORCE Fan Target to 4500 RPM (0x1194)...")
    
    # 4500 = 0x1194
    # High Byte = 0x11
    # Low Byte = 0x94
    
    write_ec_byte(TARGET_OFFSET, 0x11)
    write_ec_byte(TARGET_OFFSET + 1, 0x94)
    
    print("Done. Check if fan spins up to MAX.")

if __name__ == "__main__":
    main()
