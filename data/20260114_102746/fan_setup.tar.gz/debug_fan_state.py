#!/usr/bin/env python3
import time
import os
import sys

ACPI_CALL = "/proc/acpi/call"

def read_byte(offset):
    cmd = f"\\_SB.PC00.LPCB.H_EC.RDER {hex(offset)}"
    with open(ACPI_CALL, "w") as f: f.write(cmd)
    with open(ACPI_CALL, "r") as f: val = int(f.read().strip().replace("\x00",""), 16)
    return val

def read_word(offset):
    hib = read_byte(offset)
    lob = read_byte(offset+1)
    return (hib << 8) | lob

def main():
    if os.geteuid() != 0:
        print("Run as root")
        sys.exit(1)

    print("=== ASUS EC Fan State Debug ===")
    
    qfan = read_byte(0x61)
    print(f"QFAN Mode (0x61):   {qfan} (0=Quiet, 1=Balanced?, 2=Perf?)")
    
    target = read_word(0x40B)
    print(f"Target RPM (0x40B): {target} (Default usually 1500/0x05DC)")
    
    rpm_raw = read_word(0x470)
    print(f"RPM Count (0x470):  {rpm_raw}")
    
    # Also check 0x72? (Used in FANL method)
    # val_72 = read_byte(0x72) 
    # print(f"Reg 0x72:           {val_72}")

if __name__ == "__main__":
    main()
