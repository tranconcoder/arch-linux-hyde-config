#!/usr/bin/env python3
import time
import os
import sys
import subprocess
import threading

# Settings
ACPI_CALL = "/proc/acpi/call"
FAN_TARGET_REG_HIGH = 0x40B
FAN_TARGET_REG_LOW  = 0x40C
MAX_RPM_HEX_HI = 0x11 # 0x1194 = 4500 RPM (Safe Max)
MAX_RPM_HEX_LO = 0x94 

# You can try 5000 RPM = 0x1388?
# MAX_RPM_HEX_HI = 0x13
# MAX_RPM_HEX_LO = 0x88
# But usually firmware caps it.

RPM_READ_REG_LOW  = 0x297 # Confirmed Correct
RPM_READ_REG_HIGH = 0x298

def check_root():
    if os.geteuid() != 0:
        print("Error: This script must be run as root (sudo)")
        sys.exit(1)

def write_ec(offset, val):
    try:
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset)} {hex(val)}")
    except Exception as e:
        print(f"Error writing EC: {e}")

def read_rpm():
    try:
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.RDER {hex(RPM_READ_REG_LOW)}")
        with open(ACPI_CALL, "r") as f: lob = int(f.read().strip().replace("\x00",""), 16)
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.RDER {hex(RPM_READ_REG_HIGH)}")
        with open(ACPI_CALL, "r") as f: hib = int(f.read().strip().replace("\x00",""), 16)
        return (hib << 8) | lob
    except: return 0

def maximize_cpu():
    print("⚡ Boosting CPU...")
    
    # 1. ASUS Profile
    try:
        subprocess.run(["asusctl", "profile", "--profile-set", "Performance"], stderr=subprocess.DEVNULL)
        print("   -> asusctl: Performance")
    except:
        print("   -> asusctl: Not found/failed")

    # 2. CPU Governor
    try:
        subprocess.run(["cpupower", "frequency-set", "-g", "performance"], stdout=subprocess.DEVNULL)
        print("   -> cpupower: performance governor set")
    except:
        print("   -> cpupower: Not found")
        
    # 3. Energy Performance Preference (EPP)
    # Intel P-State usually respects this
    try:
        res = subprocess.run("echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/energy_performance_preference", shell=True, stderr=subprocess.DEVNULL)
        if res.returncode == 0:
            print("   -> EPP: set to performance")
    except: pass

def force_fan_max():
    print("🌪️  Forcing Fan to MAX Speed...")
    write_ec(FAN_TARGET_REG_HIGH, MAX_RPM_HEX_HI)
    write_ec(FAN_TARGET_REG_LOW, MAX_RPM_HEX_LO)
    print(f"   -> EC Target set to 0x{MAX_RPM_HEX_HI:02X}{MAX_RPM_HEX_LO:02X}")

def maintain_max():
    # Loop to ensure settings stick (sometimes EC reverts)
    print("\n   [Running in background. Press Ctrl+C to stop]")
    print(f"   {'Time':<10} | {'RPM (0x4E7)':<12} | {'Status'}")
    print("   " + "-"*35)
    
    try:
        while True:
            # Re-apply fan speed every 5 seconds just in case
            write_ec(FAN_TARGET_REG_HIGH, MAX_RPM_HEX_HI)
            write_ec(FAN_TARGET_REG_LOW, MAX_RPM_HEX_LO)
            
            rpm = read_rpm()
            print(f"   {time.strftime('%H:%M:%S'):<10} | {rpm:<12} | {'Running'}", end="\r")
            
            time.sleep(2)
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping...")
        # Optional: Reset to Auto?
        # write_ec(FAN_TARGET_REG_HIGH, 0x00) # Auto
        # write_ec(FAN_TARGET_REG_LOW, 0x00)
        print("   Fan control released (returned to current mode defaults).")

def main():
    check_root()
    print("=== ASUS Zenbook MAX PERFORMANCE BOOSTER v2 ===")
    
    maximize_cpu()
    force_fan_max()
    maintain_max()

if __name__ == "__main__":
    main()
