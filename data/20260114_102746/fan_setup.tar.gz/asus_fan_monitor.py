#!/usr/bin/env python3
import time
import os
import sys
import subprocess
import argparse

ACPI_CALL = "/proc/acpi/call"
RPM_OFFSET = 0x297 # Confirmed Correct RPM Register (Little Endian)

def check_root():
    if os.geteuid() != 0:
        print("Error: This script must be run as root (sudo)")
        sys.exit(1)

def read_ec_rpm():
    try:
        # Read Low Byte (0x297)
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.RDER {hex(RPM_OFFSET)}")
        with open(ACPI_CALL, "r") as f: lob = int(f.read().strip().replace("\x00",""), 16)
        
        # Read High Byte (0x298)
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.RDER {hex(RPM_OFFSET+1)}")
        with open(ACPI_CALL, "r") as f: hib = int(f.read().strip().replace("\x00",""), 16)
        
        # Combine (Little Endian)
        rpm = (hib << 8) | lob
        return rpm
    except Exception as e:
        return 0

def set_performance_mode():
    print("🚀 Activating PERFORMANCE Mode...")
    print("   [DEBUG] Setting ASUS profile to Performance...")
    # 1. ASUS Thermal Policy
    subprocess.run(["asusctl", "profile", "--profile-set", "Performance"], stdout=subprocess.DEVNULL)
    
    # 2. ENABLE Intel Turbo Boost để CPU có thể boost lên 4.6 GHz
    print("   [DEBUG] Enabling Intel Turbo Boost for maximum frequency...")
    try:
        with open("/sys/devices/system/cpu/intel_pstate/no_turbo", "w") as f:
            f.write("0")  # 0 = ENABLE turbo (cho phép boost lên 4.6 GHz)
        print("   [DEBUG] Turbo boost enabled")
    except Exception as e:
        print(f"   [WARNING] Cannot enable turbo: {e}")
    
    # 3. CPU Governor - Set cho TẤT CẢ cores
    print("   [DEBUG] Setting CPU governor to performance...")
    cpu_count = 0
    for i in range(32):  # Hỗ trợ tối đa 32 cores
        gov_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"
        if os.path.exists(gov_path):
            try:
                with open(gov_path, "w") as f:
                    f.write("performance")
                cpu_count += 1
            except Exception as e:
                print(f"   [WARNING] Cannot set governor for CPU{i}: {e}")
        else:
            break
    
    print(f"   [DEBUG] Set performance governor for {cpu_count} CPU cores")
    
    # 4. Set energy performance preference to "performance"
    print("   [DEBUG] Setting energy performance preference to maximum...")
    for i in range(cpu_count):
        try:
            epp_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/energy_performance_preference"
            if os.path.exists(epp_path):
                with open(epp_path, "w") as f:
                    f.write("performance")  # performance mode
        except:
            pass
    
    # 5. Set scaling_max_freq = cpuinfo_max_freq và scaling_min_freq cao
    print("   [DEBUG] Setting CPU frequency range for maximum performance...")
    for i in range(cpu_count):
        try:
            cpuinfo_max_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_max_freq"
            max_freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_max_freq"
            min_freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_min_freq"
            
            # Đọc max frequency từ hardware
            with open(cpuinfo_max_path, "r") as f:
                hw_max_freq = f.read().strip()
            
            # Set scaling_max = hardware max (4.6 GHz)
            with open(max_freq_path, "w") as f:
                f.write(hw_max_freq)
            
            # Set scaling_min = hardware max để force luôn chạy max
            # (với turbo enabled và performance governor, CPU sẽ boost lên 4.6 GHz)
            with open(min_freq_path, "w") as f:
                f.write(hw_max_freq)
        except Exception as e:
            print(f"   [WARNING] Cannot set freq for CPU{i}: {e}")
    
    # 6. Force High Target RPM (Just in case EC is lazy)
    print("   [DEBUG] Setting fan target RPM...")
    try:
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.WTER 0x40B 0x11") # 0x1194 = 4500
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.WTER 0x40C 0x94")
    except: pass
    
    # Verify
    time.sleep(0.5)
    try:
        with open("/sys/devices/system/cpu/intel_pstate/no_turbo", "r") as f:
            turbo_status = "ENABLED" if f.read().strip() == "0" else "DISABLED"
        with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor", "r") as f:
            current_gov = f.read().strip()
        with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", "r") as f:
            current_freq = int(f.read().strip()) / 1000  # MHz
        with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq", "r") as f:
            min_freq = int(f.read().strip()) / 1000  # MHz
        with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq", "r") as f:
            max_freq = int(f.read().strip()) / 1000  # MHz
        print(f"   ✅ Done: Turbo={turbo_status}, Governor={current_gov}")
        print(f"   📊 Freq: Min={min_freq:.0f} MHz, Max={max_freq:.0f} MHz, Current={current_freq:.0f} MHz")
    except:
        print("   ✅ Done")

def set_balanced_mode():
    print("⚖️  Activating BALANCED Mode...")
    
    # 1. Enable lại Intel Turbo Boost
    print("   [DEBUG] Enabling Intel Turbo Boost...")
    try:
        with open("/sys/devices/system/cpu/intel_pstate/no_turbo", "w") as f:
            f.write("0")  # 0 = enable turbo
    except:
        pass
    
    # 2. Set ASUS profile
    subprocess.run(["asusctl", "profile", "--profile-set", "Balanced"], stdout=subprocess.DEVNULL)
    
    # 3. Reset CPU governor
    try:
        subprocess.run(["cpupower", "frequency-set", "-g", "powersave"], stdout=subprocess.DEVNULL)
    except: 
        # Fallback: set manually
        for i in range(32):
            gov_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"
            if os.path.exists(gov_path):
                try:
                    with open(gov_path, "w") as f:
                        f.write("powersave")
                except:
                    pass
            else:
                break
    
    # 4. Reset frequency limits về default
    print("   [DEBUG] Resetting CPU frequency limits...")
    for i in range(32):
        try:
            min_freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_min_freq"
            max_freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_max_freq"
            cpuinfo_min = f"/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_min_freq"
            cpuinfo_max = f"/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_max_freq"
            
            if os.path.exists(cpuinfo_min):
                with open(cpuinfo_min, "r") as f:
                    default_min = f.read().strip()
                with open(min_freq_path, "w") as f:
                    f.write(default_min)
            
            if os.path.exists(cpuinfo_max):
                with open(cpuinfo_max, "r") as f:
                    default_max = f.read().strip()
                with open(max_freq_path, "w") as f:
                    f.write(default_max)
        except:
            pass
        
        if not os.path.exists(f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"):
            break
    
    # 5. Reset Target to Auto (1500)
    try:
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.WTER 0x40B 0x05") # 0x05DC = 1500
        with open(ACPI_CALL, "w") as f: f.write(f"\\_SB.PC00.LPCB.H_EC.WTER 0x40C 0xDC")
    except: pass
    print("   ✅ Done.")

def set_quiet_mode():
    print("🤫 Activating QUIET Mode...")
    
    # Enable lại Intel Turbo Boost
    try:
        with open("/sys/devices/system/cpu/intel_pstate/no_turbo", "w") as f:
            f.write("0")  # 0 = enable turbo
    except:
        pass
    
    subprocess.run(["asusctl", "profile", "--profile-set", "Quiet"], stdout=subprocess.DEVNULL)
    try:
        subprocess.run(["cpupower", "frequency-set", "-g", "powersave"], stdout=subprocess.DEVNULL)
    except: pass
    print("   ✅ Done.")

def get_cpu_temp():
    try:
        # Search for coretemp
        for i in range(10):
            path = f"/sys/class/hwmon/hwmon{i}"
            if os.path.exists(path):
                with open(f"{path}/name", "r") as f:
                    name = f.read().strip()
                if name == "coretemp":
                    with open(f"{path}/temp1_input", "r") as f:
                        temp = int(f.read().strip()) / 1000.0
                    return temp
        return 0
    except:
        return 0

def get_cpu_freq():
    """Lấy tần số CPU hiện tại (GHz)"""
    try:
        # Đọc từ cpuinfo (tần số trung bình của tất cả cores)
        freqs = []
        for i in range(16):  # Hỗ trợ tối đa 16 cores
            freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq"
            if os.path.exists(freq_path):
                with open(freq_path, "r") as f:
                    freq_khz = int(f.read().strip())
                    freqs.append(freq_khz / 1000000.0)  # Convert to GHz
            else:
                break
        
        if freqs:
            # Trả về tần số trung bình và max
            return sum(freqs) / len(freqs), max(freqs)
        
        # Fallback: đọc từ /proc/cpuinfo
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if "cpu MHz" in line:
                    mhz = float(line.split(":")[1].strip())
                    return mhz / 1000.0, mhz / 1000.0
        
        return 0, 0
    except:
        return 0, 0

def monitor_loop():
    print(f"Stats for ASUS UX3402VA (Reg: 0x{RPM_OFFSET:X})")
    print(f"{'Time':<10} | {'Temp':<6} | {'CPU Freq':<18} | {'RPM':<6} | {'Profile':<12}")
    print("-" * 70)
    
    while True:
        rpm = read_ec_rpm()
        temp = get_cpu_temp()
        freq_avg, freq_max = get_cpu_freq()
        
        try:
            profile = subprocess.check_output(["cat", "/sys/firmware/acpi/platform_profile"], stderr=subprocess.DEVNULL).decode().strip()
        except:
            profile = "Unknown"
        
        # Format: avg/max GHz
        freq_str = f"{freq_avg:.2f}/{freq_max:.2f} GHz"
            
        print(f"{time.strftime('%H:%M:%S'):<10} | {temp:<4.1f}°C | {freq_str:<18} | {rpm:<6} | {profile:<12}", end="\r")
        time.sleep(1)

def main():
    check_root()
    parser = argparse.ArgumentParser(description="ASUS Zenbook Fan Monitor & Control")
    parser.add_argument("-m", "--monitor", action="store_true", help="Monitor Fan RPM")
    parser.add_argument("-p", "--performance", action="store_true", help="Set Performance Mode")
    parser.add_argument("-b", "--balanced", action="store_true", help="Set Balanced Mode")
    parser.add_argument("-q", "--quiet", action="store_true", help="Set Quiet Mode")
    args = parser.parse_args()
    
    if args.performance: set_performance_mode()
    elif args.quiet: set_quiet_mode()
    elif args.balanced: set_balanced_mode()
    
    if args.monitor or not (args.performance or args.quiet or args.balanced):
        monitor_loop()

if __name__ == "__main__":
    main()
