#!/usr/bin/env python3
import time
import os
import sys

ACPI_CALL = "/proc/acpi/call"
TARGET_OFFSET = 0x40B 

def write_ec_byte(offset, value):
    cmd = f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset)} {hex(value)}"
    with open(ACPI_CALL, "w") as f: f.write(cmd)
    
def main():
    if os.geteuid() != 0:
        print("Run as root")
        sys.exit(1)

    print("Attempting to restore Fan Target to 1500 (0x05DC)...")
    
    # 1500 = 0x05DC
    # High Byte at 0x40B = 0x05
    # Low Byte at 0x40C = 0xDC
    
    write_ec_byte(TARGET_OFFSET, 0x05)
    write_ec_byte(TARGET_OFFSET + 1, 0xDC)
    
    print("Done. Check if fan spins up.")

if __name__ == "__main__":
    main()
