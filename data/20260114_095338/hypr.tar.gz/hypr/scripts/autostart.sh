#!/bin/bash
# Autostart script với polling
# [DEBUG] Flow: Mở apps -> Poll mỗi 1s -> Move app ngay khi detect

# Config: class_name -> workspace
declare -A APP_WORKSPACE=(
    ["google-chrome"]="1"
    ["kitty"]="2"
    ["DBeaver"]="3"
    ["Postman"]="3"
    ["Slack"]="4"
    ["antigravity"]="special"
)

# Track apps đã move
declare -A MOVED_APPS

echo "[DEBUG] Starting all apps..."

# Mở tất cả apps
google-chrome-stable &
kitty &
dbeaver &
postman &
slack &
antigravity &

echo "[DEBUG] Polling for windows..."

# Poll mỗi 1 giây, timeout 60s
for i in {1..60}; do
    # Lấy danh sách windows hiện tại
    clients=$(hyprctl clients -j 2>/dev/null)
    
    for class in "${!APP_WORKSPACE[@]}"; do
        # Bỏ qua nếu đã move
        [[ -n "${MOVED_APPS[$class]}" ]] && continue
        
        # Check window có tồn tại không
        if echo "$clients" | grep -q "\"class\": \"$class\""; then
            workspace="${APP_WORKSPACE[$class]}"
            echo "[DEBUG] Moving $class to workspace $workspace"
            hyprctl dispatch movetoworkspacesilent "$workspace,class:^($class)$"
            MOVED_APPS[$class]=1
        fi
    done
    
    # Thoát sớm nếu đã move hết
    if [[ ${#MOVED_APPS[@]} -eq ${#APP_WORKSPACE[@]} ]]; then
        echo "[DEBUG] All apps moved!"
        break
    fi
    
    sleep 1
done

echo "[DEBUG] Done! Moved ${#MOVED_APPS[@]}/${#APP_WORKSPACE[@]} apps"
