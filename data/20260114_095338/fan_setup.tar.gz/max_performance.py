#!/usr/bin/env python3
import os
import sys
import subprocess
import time

ACPI_CALL = "/proc/acpi/call"
TARGET_OFFSET = 0x40B # Fan Target RPM Control

def check_root():
    if os.geteuid() != 0:
        print("Error: This script must be run as root (sudo)")
        sys.exit(1)

def write_ec_byte(offset, value):
    try:
        cmd = f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset)} {hex(value)}"
        with open(ACPI_CALL, "w") as f: f.write(cmd)
    except Exception as e:
        print(f"Failed to write EC {hex(offset)}: {e}")

def set_performance():
    print("🚀 Activating MAX PERFORMANCE Mode...")
    
    # 1. ASUS Thermal Policy -> Performance
    # This usually bumps up the power limits (PL1/PL2)
    print("   - Setting asusctl profile to Performance...")
    try:
        subprocess.run(["asusctl", "profile", "--profile-set", "Performance"], 
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("   ! asusctl not found. Skipping.")

    # 2. CPU Governor -> Performance
    # Forces CPU to run at max frequency available
    print("   - Setting cpupower governor to performance...")
    try:
        subprocess.run(["cpupower", "frequency-set", "-g", "performance"], 
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("   ! cpupower (linux-tools) not found. Skipping.")

    # 3. Force Fan Target to ~4500 RPM (Max)
    # Register 0x40B (High Byte) and 0x40C (Low Byte)
    # 4500 = 0x1194 -> High: 0x11, Low: 0x94
    print("   - Writing EC Speed Target to 4500 RPM (0x1194)...")
    write_ec_byte(TARGET_OFFSET, 0x11)
    write_ec_byte(TARGET_OFFSET + 1, 0x94)
    
    print("✅ Done. Fan should spin up and CPU should be maxed.")

if __name__ == "__main__":
    check_root()
    set_performance()
