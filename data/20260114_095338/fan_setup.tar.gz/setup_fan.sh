#!/bin/bash
# Install dependencies for ASUS Fan Control

echo "📦 Installing necessary packages..."
sudo pacman -S --noconfirm acpi_call-lts cpupower python

echo "🔧 Loading kernel modules..."
sudo modprobe acpi_call

echo "⚙️  Configuring module to load on boot..."
echo "acpi_call" | sudo tee /etc/modules-load.d/acpi_call.conf

echo "✅ Setup complete!"
echo "Run: sudo ./asus_fan_monitor.py -m"
