#!/bin/bash
# Launcher for ASUS Max Performance Script
# Uses pkexec to prompt for password if not running as root

SCRIPT_PATH="/home/tvconss/max_perf_v2.py"

echo "🚀 Launching ASUS Zenbook Max Performance Mode..."

if [ "$EUID" -ne 0 ]; then
    echo "This script needs root privileges."
    echo "Requesting authentication via pkexec..."
    pkexec python3 "$SCRIPT_PATH"
else
    python3 "$SCRIPT_PATH"
fi
