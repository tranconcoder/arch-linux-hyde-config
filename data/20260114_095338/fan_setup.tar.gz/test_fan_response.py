#!/usr/bin/env python3
import time
import subprocess
import multiprocessing
import os
import sys
import signal
from asus_fan_monitor import read_ec_rpm, set_quiet_mode, set_balanced_mode, set_performance_mode

def generate_load():
    """Generates CPU load to heat up the laptop so fan kicks in."""
    while True:
        _ = 2 * 2

def start_cpu_stress(cores=None):
    if cores is None:
        cores = os.cpu_count() or 8
    print(f"🔥 Starting CPU Stress Test on {cores} processes to trigger fan...")
    processes = []
    for _ in range(cores):
        p = multiprocessing.Process(target=generate_load)
        p.daemon = True
        p.start()
        processes.append(p)
    return processes

def stop_cpu_stress(processes):
    for p in processes:
        p.terminate()

def test_mode(mode_name, set_func, duration=20):
    print(f"\n👉 Testing Mode: {mode_name.upper()}")
    set_func()
    print(f"   Waiting {duration}s for fan to adjust...")
    
    rpm_samples = []
    for i in range(duration):
        rpm = read_ec_rpm()
        rpm_samples.append(rpm)
        print(f"   [{i+1}/{duration}s] Current RPM: {rpm}", end="\r")
        time.sleep(1)
    
    avg_rpm = sum(rpm_samples[-5:]) / 5 # Average of last 5 seconds
    print(f"\n   ✅ Final Average RPM: {avg_rpm:.0f}")
    return avg_rpm

def main():
    if os.geteuid() != 0:
        print("Error: Run as root (sudo ./test_fan_response.py)")
        sys.exit(1)

    print("=== ASUS Fan Response Test ===")
    print("This script will:")
    print("1. Generate CPU load to increase temperature.")
    print("2. Cycle through Quiet -> Balanced -> Performance modes.")
    print("3. Measure Fan RPM in each mode.")
    print("==============================\n")
    
    try:
        # 1. Start Load
        load_processes = start_cpu_stress()
        
        # Warm up
        print("⏳ Warming up CPU for 10 seconds...")
        time.sleep(10)
        
        results = {}
        
        # 2. Test Quiet
        results['Quiet'] = test_mode("Quiet", set_quiet_mode, duration=30)
        
        # 3. Test Balanced
        results['Balanced'] = test_mode("Balanced", set_balanced_mode, duration=30)
        
        # 4. Test Performance
        results['Performance'] = test_mode("Performance", set_performance_mode, duration=30)
        
        # Stop Load
        stop_cpu_stress(load_processes)
        
        # 5. Summary
        print("\n" + "="*40)
        print(f"{'Mode':<15} | {'Avg RPM (Last 5s)':<15}")
        print("-" * 40)
        for mode, rpm in results.items():
            print(f"{mode:<15} | {rpm:<15.0f}")
        print("="*40)
        
        print("\nNote: RPM at 0x40B/40C usually shows ~1500 (Idle) to ~4800+ (Max).")
        print("If RPM didn't change much, the CPU might not be hot enough yet.")

    except KeyboardInterrupt:
        print("\nAborted by user.")
        try:
            stop_cpu_stress(load_processes)
        except: pass
        sys.exit(0)

if __name__ == "__main__":
    main()
