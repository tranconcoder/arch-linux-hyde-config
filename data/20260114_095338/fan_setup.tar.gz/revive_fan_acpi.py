#!/usr/bin/env python3
import time
import os
import sys

ACPI_CALL = "/proc/acpi/call"

def acpi_method_call(method, arg):
    cmd = f"{method} {arg}"
    print(f"Calling: {cmd}")
    try:
        with open(ACPI_CALL, "w") as f: f.write(cmd)
        with open(ACPI_CALL, "r") as f: 
            result = f.read().strip()
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")

def main():
    if os.geteuid() != 0:
        print("Run as root")
        sys.exit(1)

    print("=== REVIVING FAN VIA ACPI METHOD ===")
    print("Attempting to call \\_SB.ATKD.FANL 2 (Performance)...")
    
    # Try calling the standard ASUS Fan Control method
    acpi_method_call("\\_SB.ATKD.FANL", "0x2")
    
    print("Wait 5s...")
    time.sleep(5)
    
    # Also try clearing the "Stop" bit if it exists? 
    # Just forcing Target RPM again to be safe
    print("Re-enforcing Target RPM 4500...")
    cmd = f"\\_SB.PC00.LPCB.H_EC.WTER 0x40B 0x11"
    with open(ACPI_CALL, "w") as f: f.write(cmd)
    cmd = f"\\_SB.PC00.LPCB.H_EC.WTER 0x40C 0x94"
    with open(ACPI_CALL, "w") as f: f.write(cmd)
    
    print("Done. Check monitor.")

if __name__ == "__main__":
    main()
