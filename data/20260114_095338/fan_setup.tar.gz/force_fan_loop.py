#!/usr/bin/env python3
import time
import os
import sys
import subprocess

ACPI_CALL = "/proc/acpi/call"
TARGET_OFFSET = 0x40B 

def write_ec_word(offset, value):
    hib = (value >> 8) & 0xFF
    lob = value & 0xFF
    
    cmd1 = f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset)} {hex(hib)}"
    cmd2 = f"\\_SB.PC00.LPCB.H_EC.WTER {hex(offset+1)} {hex(lob)}"
    
    with open(ACPI_CALL, "w") as f: f.write(cmd1)
    with open(ACPI_CALL, "w") as f: f.write(cmd2)

def main():
    if os.geteuid() != 0:
        print("Run as root")
        sys.exit(1)

    print("=== FORCING MAX FAN SPEED (LOOP) ===")
    print("Writing Target RPM = 4800 (0x12C0) every 2 seconds...")
    print("Press Ctrl+C to stop.")
    
    try:
        while True:
            # Re-apply Target RPM to fight against EC auto-control (low temp limit)
            write_ec_word(TARGET_OFFSET, 4800)
            time.sleep(2)
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
